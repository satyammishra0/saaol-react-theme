const firebaseConfig = {
    apiKey: "AIzaSyDCQ67W0QO-9cleICWUA2vYJTj3CLGXVmI",
    authDomain: "medidove-1e1cd.firebaseapp.com",
    projectId: "medidove-1e1cd",
    storageBucket: "medidove-1e1cd.appspot.com",
    messagingSenderId: "670168320594",
    appId: "1:670168320594:web:9011b007030d3997beed8b"
};

export default firebaseConfig;