
const portfolioData = [
    {
        id: 1,
        img: 'img/portfolio/port1.jpg',
        category: 'care',
    },

    {
        id: 2,
        img: 'img/portfolio/port4.jpg',
        category: 'dental',
    },
    {
        id: 3,
        img: 'img/portfolio/port5.jpg',
        category: 'dental',
    },
    {
        id: 4,
        img: 'img/portfolio/port6.jpg',
        category: 'dental',
    },
    {
        id: 5,
        img: 'img/portfolio/port2.jpg',
        category: 'dental',
    },
    {
        id: 6,
        img: 'img/portfolio/port5.jpg',
        category: 'care',
    },
    {
        id: 7,
        img: 'img/portfolio/port2.jpg',
        category: 'medical',
    },
    {
        id: 8,
        img: 'img/portfolio/port3.jpg',
        category: 'medical',
    },
    {
        id: 9,
        img: 'img/portfolio/port1.jpg',
        category: 'surgery',
    },
    {
        id: 10,
        img: 'img/portfolio/port3.jpg',
        category: 'surgery',
    },
    {
        id: 11,
        img: 'img/portfolio/port4.jpg',
        category: 'surgery',
    },
    {
        id: 12,
        img: 'img/portfolio/port5.jpg',
        category: 'surgery',
    },
]
export default portfolioData;